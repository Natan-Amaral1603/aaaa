﻿// Uso do sistema de monitoramento de vencimento sem Observer
using observer.Models.Enum;
using observer.Models;
using Observer.Models;

class Program
{
    static void Main(string[] args)
{
    // Criando produtos
    List<Produto> produtos = new List<Produto>
        {
            new Produto(1, "Leite", new DateTime(2024, 8, 20)),
            new Produto(2, "Iogurte", new DateTime(2024, 8, 22)),
            new Produto(3, "Queijo", new DateTime(2024, 8, 19))
        };

    // Criando funcionários
    Funcionario gerente1 = new Funcionario(1, "Ana", TipoFuncionario.Gerente);
    Funcionario gerente2 = new Funcionario(2, "Pedro", TipoFuncionario.Gerente);
    Funcionario supervisor = new Funcionario(3, "Carlos", TipoFuncionario.Supervisor);
    Funcionario operador = new Funcionario(4, "Mariana", TipoFuncionario.Operador);

    // Adicionando os gerentes como observadores
    foreach (var produto in produtos)
    {
        produto.AdicionarObservador(gerente1);
        produto.AdicionarObservador(gerente2);
    }

    // Verificando produtos vencidos com a data atual
    DateTime dataAtual = DateTime.Now;

    foreach (var produto in produtos)
    {
        produto.VerificarENotificar(dataAtual);
    }
}
}