﻿using observer.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace observer.Models
{
    public class Produto
    {
        public int Id { get; private set; }
        public string Nome { get; private set; }
        public DateTime DataVencimento { get; private set; }
        private List<IObservador> observadores = new List<IObservador>();

        public Produto(int id, string nome, DateTime dataVencimento)
        {
            Id = id;
            Nome = nome;
            DataVencimento = dataVencimento;
        }

        public void AdicionarObservador(IObservador observador)
        {
            observadores.Add(observador);
        }

        public void RemoverObservador(IObservador observador)
        {
            observadores.Remove(observador);
        }

        private void NotificarObservadores()
        {
            foreach (var observador in observadores)
            {
                observador.Atualizar(this);
            }
        }

        public void VerificarENotificar(DateTime dataAtual)
        {
            if (EstaVencido(dataAtual))
            {
                NotificarObservadores();
            }
        }

        public bool EstaVencido(DateTime dataAtual)
        {
            return DataVencimento < dataAtual;
        }
    }
}