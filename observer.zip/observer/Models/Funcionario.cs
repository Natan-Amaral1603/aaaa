﻿using observer.Models.Enum;
using observer.Models;
using Observer.Models;
using System;
using System.Collections.Generic;
using observer.Interface;

namespace Observer.Models
{
    public class Funcionario : IObservador
    {
        public int Id { get; private set; }
        public string Nome { get; private set; }
        public TipoFuncionario Tipo { get; private set; }

        public Funcionario(int id, string nome, TipoFuncionario tipo)
        {
            Id = id;
            Nome = nome;
            Tipo = tipo;
        }

        public void Atualizar(Produto produto)
        {
            if (Tipo == TipoFuncionario.Gerente)
            {
                Console.WriteLine($"Gerente {Nome} notificado: Produto '{produto.Nome}' (ID: {produto.Id}) está vencido. Data de Vencimento: {produto.DataVencimento.ToShortDateString()}");
            }
        }
    }
}
