﻿using observer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace observer.Interface
{
    public interface IObservador
    {
        void Atualizar(Produto produto);
    }
}
